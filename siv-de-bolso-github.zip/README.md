# SIV de Bolso

Simulador de incidentes de parapente para treinar reações entre os voos de instrução.
Funciona no navegador, pode ser instalado como app (PWA) e roda sem internet depois da primeira visita.

> Complementa, nunca substitui, a instrução prática e o curso SIV com instrutor.

## Publicar no GitHub Pages

1. No GitHub, crie um repositório público chamado `siv-de-bolso`.
2. **Add file → Upload files** e arraste **todo o conteúdo** desta pasta
   (`index.html`, `manifest.webmanifest`, `sw.js`, `.nojekyll`, `README.md` e a pasta `icons`).
   Clique em **Commit changes**.
3. **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*,
   Branch = `main`, pasta `/ (root)` → **Save**.
4. Em 1–2 minutos o site fica em:
   `https://monteirocsar-cell.github.io/siv-de-bolso/`

## Instalar no celular

- **Android (Chrome):** abra o link → botão **Instalar app** na página (ou menu ⋮ → *Instalar app*).
- **iPhone (Safari):** abra o link → **Compartilhar** → **Adicionar à Tela de Início**.

Abra o app uma vez com internet; depois ele funciona offline (bom para a rampa).

## Atualizar

Troque os arquivos no repositório e, em `sw.js`, mude `VERSAO = 'siv-v1'` para `'siv-v2'` (e assim por diante).
Com internet, o app pega a versão nova na próxima abertura.

## Arquivos

| Arquivo | Para quê |
|---|---|
| `index.html` | O simulador inteiro (HTML, CSS e JavaScript) |
| `manifest.webmanifest` | Nome, ícones e cores do app instalado |
| `sw.js` | Cache para funcionar offline |
| `icons/` | Ícones do app |
| `.nojekyll` | Diz ao GitHub Pages para publicar os arquivos como estão |
